

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Liste des medecins</div>
                <div class="card-body">
                   <table class="table table-bordered table-striped">
                       <tr>
                           <th>Identifiant</th>
                           <th>Nom du medecin</th>
                           <th>Prenom du medecin</th>
                           <th>Telephone du medecin</th>
                           <th>Action</th>
                           <th>Action</th>
                       </tr>
                       <?php $__currentLoopData = $liste_medecins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medecin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($medecin->id); ?></td>
                                <td><?php echo e($medecin->nom); ?></td>
                                <td><?php echo e($medecin->prenom); ?></td>
                                <td><?php echo e($medecin->telephone); ?></td>
                                <td><a href="<?php echo e(route('editmedecin',['id'=>$medecin->id])); ?>">Editer</a></td>
                                <td> <a href="<?php echo e(route('deletemedecin',['id'=>$medecin->id])); ?>" onclick="return confirm('Voulez-vous supprimer ?');">Supprimer</a></td>
                            </tr>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </table> 
                   <?php echo e($liste_medecins->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Mes_Projets_L3GL\Laravel\gestionrv\resources\views/medecin/list.blade.php ENDPATH**/ ?>