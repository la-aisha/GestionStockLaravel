

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Formulaire d'enregistrement des rendez-vous</div>

                <div class="card-body">
                    <?php if(isset($confirmation)): ?>
                        <?php if($confirmation == 1): ?> 
                           <div class="alert alert-success">Rendez-vous ajouté</div>
                        <?php else: ?>
                            <div class="alert alert-danger">Rendez-vous non ajouté</div>
                        <?php endif; ?>
                    <?php endif; ?>
                    <form method="POST" action="<?php echo e(route('persistrendezvous')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label class="control-label" for="libelle">libelle du rendez-vous</label>
                            <input class="form-control" type="text" name="libelle" id="libelle">
                        </div>
                        <div class="form-group">
                            <label class="control-label" for="date">Date du rendez-vous</label>
                            <input class="form-control" type="date" name="date" id="date">
                        </div>
                        <div class="form-group">
                            <label class="control-label" for="medecins_id">Choisissez un medecin</label>
                            <select class="form-control" type="text" name="medecins_id" id="medecins_id">
                                <option value="0">Faites un choix</option>
                                <?php $__currentLoopData = $medecins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medecin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($medecin->id); ?>"><?php echo e($medecin->prenom); ?> <?php echo e($medecin->nom); ?></option> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <input class="btn btn-success" type="submit" name="envoyer" id="envoyer" value="Envoyer">
                            <input class="btn btn-danger" type="reset" name="annuler" id="annuler" value="Annuler">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Mes_Projets_L3GL\Laravel\gestionrv\resources\views/rendezvous/add.blade.php ENDPATH**/ ?>