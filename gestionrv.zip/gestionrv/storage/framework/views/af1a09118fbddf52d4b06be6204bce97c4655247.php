

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Formulaire d'enregistrement des medecins</div>

                <div class="card-body">
                    <?php if(isset($confirmation)): ?>
                        <?php if($confirmation == 1): ?>
                           <div class="alert alert-success">Medecin ajouté</div>
                        <?php else: ?>
                            <div class="alert alert-danger">Medecin non ajouté</div>
                        <?php endif; ?>
                    <?php endif; ?>
                    <form method="POST" action="<?php echo e(route('persistmedecin')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label class="control-label" for="nom">Nom du medecin</label>
                            <input class="form-control" type="text" name="nom" id="nom">
                        </div>
                        <div class="form-group">
                            <label class="control-label" for="prenom">Prenom du medecin</label>
                            <input class="form-control" type="text" name="prenom" id="prenom">
                        </div>
                        <div class="form-group">
                            <label class="control-label" for="telephone">telephone du medecin</label>
                            <input class="form-control" type="text" name="telephone" id="telephone">
                        </div>
                        <div class="form-group">
                            <input class="btn btn-success" type="submit" name="envoyer" id="envoyer" value="Envoyer">
                            <input class="btn btn-danger" type="reset" name="annuler" id="annuler" value="Annuler">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Mes_Projets_L3GL\Laravel\gestionrv\resources\views/medecin/add.blade.php ENDPATH**/ ?>